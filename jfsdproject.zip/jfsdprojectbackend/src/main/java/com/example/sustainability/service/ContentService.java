package com.example.sustainability.service;

import com.example.sustainability.entity.Lesson;
import com.example.sustainability.entity.Video;
import com.example.sustainability.repository.LessonRepository;
import com.example.sustainability.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContentService {

    @Autowired
    private LessonRepository lessonRepository;

    @Autowired
    private VideoRepository videoRepository;

    public Lesson addLesson(Lesson lesson) {
        return lessonRepository.save(lesson);
    }

    public Video addVideo(Video video) {
        return videoRepository.save(video);
    }

    public List<Lesson> getAllLessons() {
        return lessonRepository.findAll();
    }

    public List<Video> getAllVideosByLesson(Long lessonId) {
        return videoRepository.findByLesson_LessonId(lessonId);
    }
}
