package com.example.sustainability.repository;

import com.example.sustainability.entity.Engagement;
import com.example.sustainability.entity.User;
import com.example.sustainability.entity.Video;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EngagementRepository extends JpaRepository<Engagement, Long> {
    Optional<Engagement> findByUserAndVideo(User user, Video video);
}
