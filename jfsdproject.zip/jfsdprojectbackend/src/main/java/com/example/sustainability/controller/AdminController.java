package com.example.sustainability.controller;

import com.example.sustainability.entity.Lesson;
import com.example.sustainability.entity.Video;
import com.example.sustainability.service.ContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController {

    @Autowired
    private ContentService contentService;

    @PostMapping("/lessons")
    public ResponseEntity<Lesson> addLesson(@RequestBody Lesson lesson) {
        lesson.setDateCreated(new Date()); // Set creation date
        Lesson savedLesson = contentService.addLesson(lesson);
        return ResponseEntity.ok(savedLesson);
    }

    @PostMapping("/videos")
    public ResponseEntity<Video> addVideo(@RequestBody Video video) {
        Video savedVideo = contentService.addVideo(video);
        return ResponseEntity.ok(savedVideo);
    }

    @GetMapping("/lessons")
    public List<Lesson> getAllLessons() {
        return contentService.getAllLessons();
    }
}
