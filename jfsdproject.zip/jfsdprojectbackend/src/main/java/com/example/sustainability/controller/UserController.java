package com.example.sustainability.controller;

import com.example.sustainability.entity.Video;
import com.example.sustainability.entity.Engagement;
import com.example.sustainability.entity.User;
import com.example.sustainability.repository.EngagementRepository;
import com.example.sustainability.repository.UserRepository;
import com.example.sustainability.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController {

    @Autowired
    private VideoRepository videoRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EngagementRepository engagementRepository;

    // Get all videos by lesson ID
    @GetMapping("/videos/{lessonId}")
    public List<Video> getAllVideosByLesson(@PathVariable Long lessonId) {
        return videoRepository.findByLesson_LessonId(lessonId);
    }

    // Watch video and update user progress
    @PostMapping("/watch-video/{videoId}")
    public ResponseEntity<String> watchVideo(@RequestParam String email, @PathVariable Long videoId) {
        // Fetch user by email
        User user = userRepository.findByEmail(email);
        if (user == null) {
            return ResponseEntity.status(404).body("User not found");
        }

        // Fetch video by ID
        Video video = videoRepository.findById(videoId).orElse(null);
        if (video == null) {
            return ResponseEntity.status(404).body("Video not found");
        }

        // Check if the engagement exists
        Optional<Engagement> engagement = engagementRepository.findByUserAndVideo(user, video);

        // Update or create engagement
        if (engagement.isPresent()) {
            Engagement existingEngagement = engagement.get();
            existingEngagement.setCompleted(true);
            existingEngagement.setDateAccessed(new Date());
            engagementRepository.save(existingEngagement);
        } else {
            Engagement newEngagement = new Engagement();
            newEngagement.setUser(user);
            newEngagement.setVideo(video);
            newEngagement.setCompleted(true);
            newEngagement.setDateAccessed(new Date());
            engagementRepository.save(newEngagement);
        }

        return ResponseEntity.ok("Video watched and progress updated");
    }
}
