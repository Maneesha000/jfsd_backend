package com.example.sustainability.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "engagements")
public class Engagement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long engagementId;

    @ManyToOne
    private User user;

    @ManyToOne
    private Video video;

    private boolean completed;

    private Date dateAccessed;

    // Getters and setters
    public Long getEngagementId() {
        return engagementId;
    }
    public void setEngagementId(Long engagementId) {
        this.engagementId = engagementId;
    }
    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }
    public Video getVideo() {
        return video;
    }
    public void setVideo(Video video) {
        this.video = video;
    }
    public boolean isCompleted() {
        return completed;
    }
    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
    public Date getDateAccessed() {
        return dateAccessed;
    }
    public void setDateAccessed(Date dateAccessed) {
        this.dateAccessed = dateAccessed;
    }
}
