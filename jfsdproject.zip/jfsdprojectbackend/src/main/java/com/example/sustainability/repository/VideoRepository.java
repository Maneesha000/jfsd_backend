package com.example.sustainability.repository;

import com.example.sustainability.entity.Video;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VideoRepository extends JpaRepository<Video, Long> {
    List<Video> findByLesson_LessonId(Long lessonId);
}
