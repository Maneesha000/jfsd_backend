package com.example.sustainability;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JfsdprojectbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
